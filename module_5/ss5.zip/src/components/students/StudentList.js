

function StudentList() {
    return (
        <>

            <h1>Danh sách học sinh</h1>
        </>
    )
}

export default StudentList;
