import {Component} from "react";

export class Header extends Component {
    render() {
        return (
            <>
                <h3>Header</h3>
            </>
        )

    }
}